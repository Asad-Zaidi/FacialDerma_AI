import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../Nav_Bar/Header';
import Footer from '../Nav_Bar/Footer';
import '../Styles/AuthForm.css';

const SignupForm = () => {
    const [message, setMessage] = useState('');
    const navigate = useNavigate();

    const handleSignupSubmit = async (e) => {
        e.preventDefault();

        const formData = {
            username: e.target.username.value,
            email: e.target.email.value,
            age: e.target.age.value,
            gender: e.target.gender.value,
            password: e.target.password.value,
        };

        const confirmPassword = e.target.confirmPassword.value;

        if (formData.password !== confirmPassword) {
            setMessage('Passwords do not match!');
            return;
        }

        try {
            const response = await fetch('http://127.0.0.1:8000/api/auth/signup/', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData),
            });

            const data = await response.json();

            if (response.ok) {
                setMessage('Signup successful! Redirecting to login...');
                setTimeout(() => navigate('/login'), 1500);
            } else {
                setMessage('Signup failed: ' + (data.error || 'Unknown error'));
            }
        } catch (error) {
            console.error('Error:', error);
            setMessage('Something went wrong. Please try again.');
        }
    };

    return (
        <>
            <Header />
            <div className="auth-container">
                <form className="auth-form" onSubmit={handleSignupSubmit}>
                    <h2>Signup</h2>
                    <input type="text" name="username" placeholder="Username" required />
                    <input type="email" name="email" placeholder="Email" required />
                    <input type="number" name="age" placeholder="Age" min="0" required />
                    <select name="gender" defaultValue="" required>
                        <option value="" disabled>Gender</option>
                        <option value="female">Female</option>
                        <option value="male">Male</option>
                        <option value="other">Other</option>
                    </select>
                    <input type="password" name="password" placeholder="Password" required />
                    <input type="password" name="confirmPassword" placeholder="Confirm Password" required />
                    <button type="submit">Signup</button>
                    {message && <div className="auth-message">{message}</div>}
                    <p className="switch-text">
                        Already have an account?{' '}
                        <span onClick={() => navigate('/login')} className="switch-link">Login</span>
                    </p>
                </form>
            </div>
            <Footer />
        </>
    );
};

export default SignupForm;
