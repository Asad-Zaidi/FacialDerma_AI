import React, { useContext, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../contexts/AuthContext';
import Header from '../Nav_Bar/Header';
import Footer from '../Nav_Bar/Footer';
import '../Styles/AuthForm.css';

const LoginForm = () => {
    const [message, setMessage] = useState('');
    const navigate = useNavigate();
    const { login } = useContext(AuthContext);

    const handleLoginSubmit = async (e) => {
        e.preventDefault();

        const formData = {
            identifier: e.target.identifier.value,
            password: e.target.password.value,
        };

        try {
            const response = await fetch('http://127.0.0.1:8000/api/auth/login/', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData),
            });

            const data = await response.json();

            if (response.ok) {
                login(data.access_token);
                localStorage.setItem('refresh_token', data.refresh_token);
                localStorage.setItem('user', JSON.stringify(data.user || {}));
                setMessage('Login successful! Redirecting...');
                setTimeout(() => navigate('/profile'), 1500);
            } else {
                setMessage('Login failed: ' + (data.error || 'Unknown error'));
            }
        } catch (error) {
            console.error('Error:', error);
            setMessage('Something went wrong. Please try again.');
        }
    };

    return (
        <>
            <Header />
            <div className="auth-container">
                <form className="auth-form" onSubmit={handleLoginSubmit}>
                    <h2>Login</h2>
                    <input type="text" name="identifier" placeholder="Username or Email" required />
                    <input type="password" name="password" placeholder="Password" required />
                    <button type="submit">Login</button>
                    {message && <div className="auth-message">{message}</div>}
                    <p className="switch-text">
                        Don't have an account?{' '}
                        <span onClick={() => navigate('/signup')} className="switch-link">Signup</span>
                    </p>
                </form>
            </div>
            <Footer />
        </>
    );
};

export default LoginForm;
